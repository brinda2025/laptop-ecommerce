package com.laptop.productservice.exception;

public class ProductServiceCustomException {

}
